--enable admin privileges for everyone, for debugging purposes
UPDATE OR FAIL UserAccounts SET admin = 1;