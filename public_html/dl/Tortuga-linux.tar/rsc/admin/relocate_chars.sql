-- simply dump all characters at (0,0) in room 0, for debugging purposes
UPDATE OR FAIL LiveCharacters SET roomIndex = 0, originX = 0, originY = 0;